---
name: openclaw-commit-id-merge-only
description: >
  Merges one or more specific commits into a target branch by commit ID directly,
  without path whitelist filtering. Use when the user asks to merge by commit ID
  and wants full commit content copied as-is.
---
# OpenClaw Commit ID Direct Merge

## Goal

Merge by commit ID directly, without whitelist path filtering.
Use `git cherry-pick -x` to preserve source commit traceability.

## Safety Rules

1. Always verify current branch and working tree first.
2. Never use `git merge`/`git rebase` for this task unless user explicitly asks.
3. Never run destructive commands (`reset --hard`, `checkout -- .`) unless explicitly requested.
4. If cherry-pick conflicts occur, stop and ask whether to resolve now or abort.

## Required Inputs

- `<TARGET_BRANCH>`: branch to receive commit(s)
- `<COMMIT_ID>` or `<COMMIT_ID_1,COMMIT_ID_2,...>`: source commit ID(s)

If missing, ask a concise follow-up question.

## Standard Workflow

### Step 1: Pre-check

```bash
git rev-parse --abbrev-ref HEAD
git status --short
git show --name-only --pretty=format: <COMMIT_ID>
```

Confirm:
- commit exists
- target branch is correct
- working tree is clean

### Step 2: Switch branch

```bash
git switch <TARGET_BRANCH>
```

### Step 3: Direct merge by commit ID

Single commit:

```bash
git cherry-pick -x <COMMIT_ID>
```

Multiple commits in order:

```bash
git cherry-pick -x <COMMIT_ID_1> <COMMIT_ID_2> <COMMIT_ID_3>
```

### Step 4: Verify result

```bash
git status --short
git log -1 --stat
```

## Script Mode (Recommended)

### Single commit

```bash
bash scripts/selective-merge-by-commit.sh <TARGET_BRANCH> <COMMIT_ID>
```

Example:

```bash
bash scripts/selective-merge-by-commit.sh feature/openclaw-v2 abc1234
```

### Multiple commits

```bash
bash scripts/selective-merge-by-commits.sh <TARGET_BRANCH> <COMMIT_ID_1,COMMIT_ID_2,...>
```

Example:

```bash
bash scripts/selective-merge-by-commits.sh release/skills-sync abc1234,def5678,9012abc
```

## Troubleshooting

### Working tree not clean

Symptom:
- script or cherry-pick exits before merge

Action:
1. Ask user to commit/stash local changes first
2. Re-run command

### Unknown commit ID

Symptom:
- `bad revision` or `unknown revision`

Action:

```bash
git rev-parse --verify <COMMIT_ID>
```

Ask user for a correct SHA if verification fails.

### Conflict during cherry-pick

Symptom:
- `CONFLICT` appears in output

Action:
1. Ask user to choose:
   - resolve conflicts and continue
   - abort current cherry-pick
2. If user chooses abort:

```bash
git cherry-pick --abort
```

## Response Style For User

Return:

1. used commit ID(s)
2. target branch
3. whether cherry-pick succeeded or had conflicts
4. final commit ID on target branch

Keep output concise and auditable.
---
name: openclaw-commit-id-merge-only
description: >
  Selectively merges only user-specified changes from one or more commit IDs,
  while excluding unrelated files and commits. Use when the user asks to merge
  by commit ID but only for specific paths or specific hunks, such as openclaw
  skills updates.
---
# OpenClaw Commit ID Precision Merge

## Goal

When the user asks to "merge by commit ID but only specific changes", do NOT use plain merge/rebase.
Use a controlled workflow that only transfers approved files or hunks from source commits.

## Safety Rules

1. Always verify current branch and working tree first.
2. Never run `git merge <branch>` for this task.
3. Never run destructive commands (`reset --hard`, `checkout -- .`) unless explicitly requested.
4. Prefer `cherry-pick -n` (no commit) + restore/reset of non-target changes.
5. If target files overlap with local dirty changes, stop and ask the user whether to stash or continue manually.

## Required Inputs

- Source commit ID(s): one or multiple SHAs.
- Target branch: where the changes should land.
- Allowed scope:
  - Option A: allowed file paths list
  - Option B: allowed partial hunks in a file

If any input is missing, ask a concise follow-up question before running commands.

## How To Use

### Quick Start

1. Collect 4 parameters from user:
   - `<TARGET_BRANCH>`
   - `<COMMIT_ID>` or `<COMMIT_ID_1> <COMMIT_ID_2> ...`
   - Allowed paths (for whitelist mode)
   - Whether partial hunks are needed (`yes/no`)
2. Switch to target branch and run pre-check commands.
3. Run `cherry-pick -n` to load commit changes into working tree without commit.
4. Keep only approved paths/hunks.
5. Verify staged diff only contains approved changes.
6. Commit with source commit trace in message.

### Success Criteria

- `git diff --staged` only includes user-approved openclaw skills edits.
- No unrelated file in staged area.
- Commit message contains source commit ID(s).

## Standard Workflow

### Step 1: Pre-check

Run:

```bash
git rev-parse --abbrev-ref HEAD
git status --short
git show --name-only --pretty=format: <COMMIT_ID>
```

Confirm:
- You are on the target branch.
- The commit contains the expected openclaw/skills changes.

### Step 2: Apply commit without auto-commit

Run:

```bash
git cherry-pick -n <COMMIT_ID>
```

For multiple commits, apply in order:

```bash
git cherry-pick -n <COMMIT_ID_1> <COMMIT_ID_2> <COMMIT_ID_3>
```

### Step 3A: Keep only allowed files (most common)

Reset all unstaged/staged changes from this pick:

```bash
git restore --staged --worktree .
```

Bring back only approved paths from commit:

```bash
git restore --source <COMMIT_ID> -- \
  <ALLOWED_PATH_1> \
  <ALLOWED_PATH_2>
```

Stage only allowed paths:

```bash
git add <ALLOWED_PATH_1> <ALLOWED_PATH_2>
```

### Step 3B: Keep only allowed hunks (file-level partial pick)

If only part of a file is needed:

```bash
git checkout -p <COMMIT_ID> -- <TARGET_FILE>
git add <TARGET_FILE>
```

Use interactive choices:
- `y`: accept hunk
- `n`: reject hunk
- `s`: split hunk
- `e`: edit hunk manually

### Step 4: Verify no unrelated changes

Run:

```bash
git status --short
git diff --staged
```

Ensure staged diff contains only approved openclaw skills edits.

### Step 5: Commit

Use a message that records source commit traceability:

```bash
git commit -m "chore(skills): selectively merge openclaw skill changes from <COMMIT_ID>"
```

If multiple commits:

```bash
git commit -m "chore(skills): selectively merge openclaw skill changes from <COMMIT_ID_1>, <COMMIT_ID_2>"
```

## Conflict Handling

If `cherry-pick -n` conflicts:

1. Resolve conflicts only in approved files.
2. For unapproved files in conflict, discard conflict file changes:

```bash
git restore --source HEAD -- <UNAPPROVED_FILE>
```

3. Continue with Step 4 verification before commit.

If conflict scope is unclear, stop and ask the user.

## Command Templates

### Template A: Single commit + path whitelist

```bash
git switch <TARGET_BRANCH> && \
git cherry-pick -n <COMMIT_ID> && \
git restore --staged --worktree . && \
git restore --source <COMMIT_ID> -- <PATH_1> <PATH_2> && \
git add <PATH_1> <PATH_2> && \
git diff --staged && \
git commit -m "chore(skills): selectively merge from <COMMIT_ID>"
```

### Template B: Multiple commits + path whitelist

```bash
git switch <TARGET_BRANCH> && \
git cherry-pick -n <COMMIT_ID_1> <COMMIT_ID_2> && \
git restore --staged --worktree . && \
git restore --source <COMMIT_ID_1> -- <PATH_1> && \
git restore --source <COMMIT_ID_2> -- <PATH_2> && \
git add <PATH_1> <PATH_2> && \
git diff --staged && \
git commit -m "chore(skills): selectively merge from <COMMIT_ID_1>, <COMMIT_ID_2>"
```

## Examples

### Example 1: Single commit, keep only one skill file

Scenario:
- Source commit: `abc1234`
- Target branch: `feature/openclaw-v2`
- Keep only: `.cursor/skills/openclaw-commit-id-merge-only/SKILL.md`

```bash
git switch feature/openclaw-v2
git cherry-pick -n abc1234
git restore --staged --worktree .
git restore --source abc1234 -- .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
git add .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
git diff --staged
git commit -m "chore(skills): selectively merge from abc1234"
```

### Example 2: Multiple commits, keep different files from each

Scenario:
- Source commits: `abc1234`, `def5678`
- Target branch: `release/skills-sync`
- Keep:
  - from `abc1234`: `.cursor/skills/openclaw-commit-id-merge-only/SKILL.md`
  - from `def5678`: `.cursor/skills/openclaw-commit-id-merge-only/examples.md`

```bash
git switch release/skills-sync
git cherry-pick -n abc1234 def5678
git restore --staged --worktree .
git restore --source abc1234 -- .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
git restore --source def5678 -- .cursor/skills/openclaw-commit-id-merge-only/examples.md
git add .cursor/skills/openclaw-commit-id-merge-only/SKILL.md .cursor/skills/openclaw-commit-id-merge-only/examples.md
git diff --staged
git commit -m "chore(skills): selectively merge from abc1234, def5678"
```

### Example 3: Only part of one file (interactive hunk pick)

Scenario:
- Source commit: `abc1234`
- Target branch: `feature/openclaw-lite`
- File: `.cursor/skills/openclaw-commit-id-merge-only/SKILL.md`
- Need only specific sections

```bash
git switch feature/openclaw-lite
git cherry-pick -n abc1234
git restore --staged --worktree .
git checkout -p abc1234 -- .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
git add .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
git diff --staged
git commit -m "chore(skills): selectively merge partial hunks from abc1234"
```

During `checkout -p`:
- Press `y` to keep hunk
- Press `n` to skip hunk
- Press `s` to split hunk
- Press `e` to edit hunk

## Placeholder Reference

Use these placeholder meanings consistently:

- `<TARGET_BRANCH>`: branch that should receive selected changes.
- `<COMMIT_ID>`: source commit SHA (short or full).
- `<COMMIT_ID_1> <COMMIT_ID_2>`: multiple source commits in apply order.
- `<ALLOWED_PATH_1> <ALLOWED_PATH_2>`: file path whitelist to keep.
- `<TARGET_FILE>`: file path for partial hunk picking.
- `<UNAPPROVED_FILE>`: file that must NOT be merged.

Fill rules:

1. Prefer full SHA for auditability in critical merges.
2. Paths must be repo-relative and exact.
3. If same file is touched by multiple commits, apply commit order from old to new.

## Pre-Run Checklist

Before executing commands, verify:

- `git status --short` is clean, or user explicitly approved operating on dirty tree.
- You are on `<TARGET_BRANCH>`.
- `git show --name-only --pretty=format: <COMMIT_ID>` includes expected files.
- User has explicitly confirmed whitelist paths or hunk scope.

## Troubleshooting

### Error: working tree not clean

Symptom:
- `git cherry-pick -n` fails due to local changes.

Action:
1. Ask user to choose:
   - commit/stash local changes first, then continue
   - or cancel this operation
2. Do not auto-discard user changes.

### Error: bad revision / unknown commit

Symptom:
- `fatal: bad revision '<COMMIT_ID>'` or `unknown revision`.

Action:
1. Verify SHA exists:

```bash
git rev-parse --verify <COMMIT_ID>
```

2. If missing, ask user to provide correct commit SHA.

### Error: path not in commit

Symptom:
- restore/checkout path command fails.

Action:
1. Inspect files in commit:

```bash
git show --name-only --pretty=format: <COMMIT_ID>
```

2. Correct path or remove invalid path from whitelist.

### Conflict during cherry-pick

Symptom:
- `CONFLICT` after `git cherry-pick -n`.

Action:
1. Resolve only approved files.
2. For unapproved conflict files:

```bash
git restore --source HEAD -- <UNAPPROVED_FILE>
```

3. Re-run:

```bash
git status --short
git diff --staged
```

4. Commit only after staged diff is clean and scoped.

### Wrong changes accidentally staged

Symptom:
- staged diff contains unrelated files.

Action:
1. Unstage/reset working tree changes:

```bash
git restore --staged --worktree .
```

2. Re-apply only whitelist paths from source commit.

## Optional Audit Commands

Use these checks when user needs stronger traceability:

```bash
git log -1 --stat
git show --name-only --pretty=fuller HEAD
```

Report:
- source commit IDs
- kept paths/hunks
- final target commit ID

## Script Mode (Recommended)

Use the helper script for single-commit + path-whitelist merges:

```bash
bash scripts/selective-merge-by-commit.sh <TARGET_BRANCH> <COMMIT_ID> <PATH_1> [PATH_2 ...]
```

Example:

```bash
bash scripts/selective-merge-by-commit.sh feature/openclaw-v2 abc1234 \
  .cursor/skills/openclaw-commit-id-merge-only/SKILL.md
```

Script behavior:

1. Verify commit exists.
2. Require clean working tree.
3. Switch to target branch.
4. `cherry-pick -n` source commit.
5. Clear all brought changes.
6. Restore only whitelist paths from source commit.
7. Commit with source commit ID in message.

## Script Mode (Multiple Commits)

Use the helper script for multi-commit + path-whitelist merges:

```bash
bash scripts/selective-merge-by-commits.sh <TARGET_BRANCH> <COMMIT_ID_1,COMMIT_ID_2,...> <PATH_1> [PATH_2 ...]
```

Example:

```bash
bash scripts/selective-merge-by-commits.sh release/skills-sync abc1234,def5678 \
  .cursor/skills/openclaw-commit-id-merge-only/SKILL.md \
  .cursor/skills/openclaw-commit-id-merge-only/examples.md
```

Script behavior:

1. Verify all commit IDs exist.
2. Require clean working tree.
3. Switch to target branch.
4. `cherry-pick -n` all source commits in order.
5. Clear all brought changes.
6. Restore only whitelist paths from each commit in order.
7. Stage whitelist paths and verify staged diff.
8. Commit with all source commit IDs in message.

## Response Style For User

When executing this skill, return:

1. What commit ID(s) were used.
2. What exact paths/hunks were kept.
3. Confirmation that unrelated changes were excluded.
4. Final commit ID on target branch.

Keep output concise and auditable.
