#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
用法:
  scripts/selective-merge-by-commit.sh <target_branch> <commit_id>

示例:
  scripts/selective-merge-by-commit.sh feature/openclaw-v2 abc1234

说明:
  - 按 commit ID 直接合并到目标分支
  - 不使用白名单路径筛选
  - 使用 cherry-pick -x，自动在提交信息中记录来源 commit
EOF
}

if [[ $# -ne 2 ]]; then
  usage
  exit 1
fi

TARGET_BRANCH="$1"
COMMIT_ID="$2"

echo "[1/4] 检查 commit 是否存在..."
git rev-parse --verify "${COMMIT_ID}^{commit}" >/dev/null

echo "[2/4] 检查工作区是否干净..."
if [[ -n "$(git status --porcelain)" ]]; then
  echo "工作区不干净，请先提交或 stash 后再执行。"
  exit 1
fi

echo "[3/4] 切换到目标分支: ${TARGET_BRANCH}"
git switch "${TARGET_BRANCH}"

echo "[4/4] 直接合并 commit: ${COMMIT_ID}"
git cherry-pick -x "${COMMIT_ID}"

echo "完成。"
echo "最终提交: $(git rev-parse --short HEAD)"
