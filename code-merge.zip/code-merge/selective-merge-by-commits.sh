#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
用法:
  scripts/selective-merge-by-commits.sh <target_branch> <commit_id_1,commit_id_2,...>

示例:
  scripts/selective-merge-by-commits.sh release/skills-sync abc1234,def5678,9012abc

说明:
  - 按顺序直接合并多个 commit 到目标分支
  - 不使用白名单路径筛选
  - 使用 cherry-pick -x，自动在提交信息中记录来源 commit
EOF
}

if [[ $# -ne 2 ]]; then
  usage
  exit 1
fi

TARGET_BRANCH="$1"
COMMITS_RAW="$2"

IFS=',' read -r -a COMMIT_IDS <<<"${COMMITS_RAW}"
if [[ ${#COMMIT_IDS[@]} -eq 0 ]]; then
  echo "未提供有效 commit 列表。"
  exit 1
fi

echo "[1/5] 检查 commit 是否存在..."
for commit in "${COMMIT_IDS[@]}"; do
  git rev-parse --verify "${commit}^{commit}" >/dev/null
done

echo "[2/5] 检查工作区是否干净..."
if [[ -n "$(git status --porcelain)" ]]; then
  echo "工作区不干净，请先提交或 stash 后再执行。"
  exit 1
fi

echo "[3/5] 切换到目标分支: ${TARGET_BRANCH}"
git switch "${TARGET_BRANCH}"

echo "[4/5] 按顺序直接合并多个 commit..."
git cherry-pick -x "${COMMIT_IDS[@]}"

echo "[5/5] 完成"
echo "最终提交: $(git rev-parse --short HEAD)"
