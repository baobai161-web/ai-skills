---
name: user_commit_count
description: >-
  统计指定作者在 Git 中的提交次数；支持本地仓库、GitHub（gh）、GitLab（REST API 或本地克隆）。
  在用户询问「某用户提交数」「某人 commit 数量」「按作者统计提交」「GitLab 某时间段全分支提交数」等时使用。
metadata:
  openclaw:
    requires:
      bins:
        - git
---

# 指定用户提交数

## 何时使用

用户给出**用户名 / 作者名 / 邮箱 / GitHub 或 GitLab 登录名**，想知道**提交（commit）条数**。默认指 **Git 提交**；若用户明确说是 **MR、Issue、合并请求数量**，改用对应 API，勿把 commit 统计当成 MR 数。

## 前置确认（缺一则先问用户）

1. **范围**：当前工作区是否为目标仓库根目录？若不是，请用户提供**本地路径**或 **GitHub `owner/repo` / GitLab `group/project`（URL 编码）**。
2. **时间**：**起止日期**（含时区意图）。GitLab API 需 **ISO 8601**（如 `2025-01-01T00:00:00Z`）；本地 `git` 也可用相对时间（如 `30 days ago`）。
3. **作者标识**：**Git 提交里的 author** 以 **name / email** 为准；**GitLab 账号名**与 commit author 可能不一致。优先让用户提供 **commit 所用邮箱**；不清楚时先用 `git shortlog -sne --all` 列候选。

## 安全

通过 **exec** 跑命令时，**禁止**把用户输入原样拼进 shell 做解析。将作者字符串当作**单个字面量参数**传递（例如传给 `git` 的 `--author=` 时整体加引号并由调用方做转义，或只用字母数字与少量安全字符；含引号、反引号、`$()`、分号等时拒绝或要求用户改为邮箱等安全形式）。

## 流程 A：本地仓库（优先）

在已确认的仓库根目录执行（路径按实际替换）：

1. 列出作者候选（用户说不清用哪个名字时）：

   ```bash
   git -C "<repo_root>" shortlog -sne --all
   ```

2. **全历史**提交数（按 `--author` 子串匹配，Git 默认行为）：

   ```bash
   git -C "<repo_root>" rev-list --count --all --author="<author_literal>"
   ```

3. **指定日期范围 + 所有分支**（按提交时间过滤，去重同一条 commit）：

   ```bash
   git -C "<repo_root>" fetch --all --prune
   git -C "<repo_root>" rev-list --count --all --author="<author_literal>" --since="<start>" --until="<end>"
   ```

   `--since` / `--until` 含义以 Git 文档为准；边界若与用户预期差一天，改用 UTC 午夜或调整 `until` 为次日零点。

4. 回复用户时写明：**仓库路径**、**作者匹配串**、**`--all` 含所有 refs**、**起止时间**，并说明统计的是 **唯一 commit SHA 条数**（amend 会产生新 SHA）。

## 流程 B：GitHub 远程（可选，需 `gh` 且已 `gh auth login`）

当用户要统计 **GitHub 上某仓库** 中某用户的提交、且本机有 `gh`：

1. 使用 `gh api`，注意 **分页**：需循环拉取直到无下一页，或使用 `gh` 支持的一次性查询方式，**不得**只取第一页当总数。
2. 将 **GitHub login** 与 **Git author 字符串**区分说明；若与本地 `git log` 不一致，以用户指定的平台为准。

若未安装或未登录 `gh`，说明限制并退回流程 A（克隆到本地再统计）或请用户安装认证。

## 流程 C：GitLab（指定日期范围 + 全仓库所有分支 + 指定作者）

适用于用户明确提到 **GitLab**，或 remote 为 `gitlab.com` / 自建 GitLab。

### 优先：本地已有克隆（与流程 A 一致）

1. 确认 `origin` 等远程已包含目标历史：`git fetch --all --prune`。
2. 使用与流程 A 相同的命令：

   `git rev-list --count --all --author="<author_literal>" --since="<start>" --until="<end>"`

该方式在本地对 **所有 refs** 去重统计，与「全分支」语义一致，且不消耗 API 额度。

### 无克隆或必须以 GitLab 服务端为准：REST API

参考官方 [List repository commits](https://docs.gitlab.com/ee/api/commits.html)：

- 端点：`GET /api/v4/projects/:id/repository/commits`
- **全分支 / 全仓库可达提交**：查询参数 **`all=true`**（为 `true` 时 **`ref_name` 被忽略**）。
- **日期**：`since`、`until` 为 **ISO 8601**（文档示例格式 `YYYY-MM-DDTHH:MM:SSZ`）；区间为「on or after `since`」且「on or before `until`」。
- **作者**：`author` 为字符串，按 **commit author** 搜索；**优先使用用户邮箱**，匹配更稳。
- **分页**：使用 `page`、`per_page`（如 100）**循环请求直到本页条数小于 `per_page`**。该接口**不返回** `x-total` / `x-total-pages`，不可假设一页即全部。
- **计数**：以返回 JSON 数组元素个数累加；若担心极端情况下重复 SHA，对每条记录的 **`id`（SHA）做集合去重后再取 count**。
- **认证**：使用 **Personal Access Token** / Project Token 等，放在请求头 **`PRIVATE-TOKEN`**（或当前实例文档要求的 Bearer 方式）。Token 来自环境变量（如 `GITLAB_TOKEN`），**禁止**写入 skill、日志或回显给用户。

`project :id` 可为数字 id 或 **URL 编码的带命名空间路径**（如 `group%2Fproject`）。

### 兜底：不支持或无法使用 `all=true` 时（按分支拉取 + SHA 去重）

在以下情况改用本兜底，并**始终用 commit 的 `id`（SHA）做全局去重**后再 `count`，禁止按「各分支条数相加」直接报总数：

- 请求带 `all=true` 返回 **400 / 404**、或文档显示当前版本**无此参数**；
- `all=true` 返回条数与本地 `git rev-list --all`（同时间窗、同作者）**严重不一致**，用户要求以 API 为准需复核时；
- 运维策略**禁止**使用 `all`（少数自建实例会关特性）。

**步骤：**

1. **枚举分支**（分页）：`GET /api/v4/projects/:id/repository/branches`，使用 `page` / `per_page`，直到本页分支数小于 `per_page`。收集每条记录的 **`name`**（分支名）。若还需统计 **tag 上的独有提交**，再同样分页调用 `GET /api/v4/projects/:id/repository/tags`，收集 **tag 名** 并入 ref 列表（与「仅所有分支」语义不同时，回复里写清楚包含 tag）。

2. **对每个 ref 拉 commits**：对列表中每个 `ref_name`（分支名或 tag 名）调用  
   `GET /api/v4/projects/:id/repository/commits?ref_name=<URL 编码后的 ref>&since=...&until=...&author=...`  
   分支名含 `/`、`#` 等时必须正确 **URL 编码**。**不得**传 `all`。同样按 `page` / `per_page` 翻页直到结束。

3. **去重计数**：把所有页、所有 ref 返回中的 **`id`** 放入同一集合（Set），最终 **`len(Set)`** 即为「该时间窗内、这些 ref 可达的、去重后的 commit 数」。

4. **注意**：同一 commit 若在多个分支上可见，会出现在多次列表中，**不去重会严重重复计数**，故步骤 3 必须执行。分支/标签很多时请求次数多，注意 **速率限制**；若频繁触发，应建议用户改用**本地克隆 + 流程 A**。

### GitLab 与「用户」的说明

- **GitLab Username** 不一定等于 **git config 的 user.name**；统计的是 **commit 元数据里的 author**，不是「账号在网页上显示名」。
- 若 `author` 过滤结果为空，让用户在网页上打开其一条 commit，核对 **Author** 行的 name/email，再用该字符串重试。

## 输出格式

用简短中文回复，例如：

- 仓库：`...`
- 作者匹配：`...`
- 统计：共 **N** 次提交（范围：本地 `--all` / GitLab `all=true` / 或兜底「多 ref + SHA 去重」；时间：…）

若 **N 为 0**，提示可能是作者名 / 邮箱不匹配，并给出 `shortlog -sne --all` 或 GitLab 上一条该用户 commit 的 author 信息供核对。
